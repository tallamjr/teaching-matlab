function f = yp( t,y )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
f = 1/t^2*(y + 3)
end

