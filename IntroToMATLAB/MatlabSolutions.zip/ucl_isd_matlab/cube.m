function [cubed] = cube( x )
%cube Returns variable to ^3
%   no more detail needed
cubed = x^3;
end

